
clear all;
data_dir = 'map_folder/table5_pidinet';
ablation = false;
suffix = '_epoch_013';

% Data directory data_dir should be defined outside.
fprintf('Data dir: %s\n', data_dir);
addpath(genpath('./edges'));
addpath(genpath('./toolbox.badacost.public'));

tic;
% Section 1: NMS process (formerly nms_process.m from HED repo).
disp('NMS process...')
mat_dir = fullfile(data_dir, ['mats', suffix]);
nms_dir = fullfile(data_dir, ['nms', suffix]);
edgesEvalnoPlot(nms_dir,'PiDiNet');
