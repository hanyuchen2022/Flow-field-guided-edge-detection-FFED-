 
clear all;
%data_dir = 'map_folder/nyud_image';
%data_dir2 = 'map_folder/nyud_hha';
data_dir = 'F:/data_ep13/img_ep13_results';
data_dir2 = 'F:/data_ep13/hha_ep13_results';

gtDir = './data/gt/nyud'
suffix = '_epoch_012';

% Data directory data_dir should be defined outside.
fprintf('Data dir: %s\n', data_dir);
addpath(genpath('./edges'));
addpath(genpath('./toolbox.badacost.public'));

tic;
% Section 1: NMS process (formerly nms_process.m from HED repo).
disp('NMS process...')
mat_dir = fullfile(data_dir, ['mats', suffix]);
mat_dir2 = fullfile(data_dir2, ['mats', suffix]);
nms_dir = fullfile(data_dir, ['nms_combine', suffix]);
mkdir(nms_dir)

files = dir(mat_dir);
files = files(3:end,:);  % It means all files except ./.. are considered.
mat_names = cell(1,size(files, 1));
nms_names = cell(1,size(files, 1));
for i = 1:size(files, 1),
    mat_names{i} = files(i).name;
    nms_names{i} = [files(i).name(1:end-4), '.png']; % Output PNG files.
end

for i = 1:size(mat_names,2),
    matObj = matfile(fullfile(mat_dir, mat_names{i})); % Read MAT files.
    varlist = who(matObj);
    x1 = matObj.(char(varlist));
    matObj2 = matfile(fullfile(mat_dir2, mat_names{i})); % Read MAT files.
    varlist2 = who(matObj2);
    x2 = matObj2.(char(varlist2));
    x = (x1 + x2) / 2;
    E=convTri(single(x),1);
    [Ox,Oy]=gradient2(convTri(E,4));
    [Oxx,~]=gradient2(Ox); [Oxy,Oyy]=gradient2(Oy);
    O=mod(atan(Oyy.*sign(-Oxy)./(Oxx+1e-5)),pi);
    %E=edgesNmsMex(E,O,1,5,1.01,4);
    E=edgesNmsMex(E,O,4,5,1.01,4);
    imwrite(uint8(E*255),fullfile(nms_dir, nms_names{i}))
end

% Section 2: Evaluate the edges (formerly EvalEdge.m from HED repo).
disp('Evaluate the edges...');
%gtDir  = 'data/groundTruth/test';
%resDir = fullfile(data_dir, 'nms');
resDir = nms_dir;
edgesEvalDir('resDir',resDir,'gtDir',gtDir, 'thin', 1, 'pDistr',{{'type','parfor'}},'maxDist',0.011);

% figure; 
edgesEvalnoPlot(resDir,'PiDiNet');

rmdir(mat_dir, 's');
rmdir(mat_dir2, 's');
rmdir(nms_dir, 's');
toc;

