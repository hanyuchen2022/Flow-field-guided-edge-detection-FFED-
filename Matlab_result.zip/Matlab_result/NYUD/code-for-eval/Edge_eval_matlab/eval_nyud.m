
clear all;
data_dir = 'F:/data/img_eval_results';    %F:\data\nyud_edge\nms_epoch_014
gtDir = './data/gt/nyud'
suffix = '_epoch_014';

% Data directory data_dir should be defined outside.
fprintf('Data dir: %s\n', data_dir);
addpath(genpath('./edges'));
addpath(genpath('./toolbox.badacost.public'));

tic;
% Section 1: NMS process (formerly nms_process.m from HED repo).
disp('NMS process...')
mat_dir = fullfile(data_dir, ['mats', suffix]);
nms_dir = fullfile(data_dir, ['nms', suffix]);
mkdir(nms_dir)
disp(['mat_dir:',mat_dir])
disp(['nms_dir:',nms_dir])

files = dir(mat_dir);
files = files(3:end,:);  % It means all files except ./.. are considered.
mat_names = cell(1,size(files, 1));
nms_names = cell(1,size(files, 1));
for i = 1:size(files, 1),
    mat_names{i} = files(i).name;
    nms_names{i} = [files(i).name(1:end-4), '.png']; % Output PNG files.
end

for i = 1:size(mat_names,2),
    matObj = matfile(fullfile(mat_dir, mat_names{i})); % Read MAT files.
    varlist = who(matObj);
    x = matObj.(char(varlist));
    E=convTri(single(x),1);
    [Ox,Oy]=gradient2(convTri(E,4));
    [Oxx,~]=gradient2(Ox); [Oxy,Oyy]=gradient2(Oy);
    O=mod(atan(Oyy.*sign(-Oxy)./(Oxx+1e-5)),pi);
    %E=edgesNmsMex(E,O,1,5,1.01,4);
    E=edgesNmsMex(E,O,4,5,1.01,4);
    imwrite(uint8(E*255),fullfile(nms_dir, nms_names{i}))
end

% Section 2: Evaluate the edges (formerly EvalEdge.m from HED repo).
disp('Evaluate the edges...');
%gtDir  = 'data/groundTruth/test';
%resDir = fullfile(data_dir, 'nms');
resDir = nms_dir;
edgesEvalDir('resDir',resDir,'gtDir',gtDir, 'thin', 1, 'pDistr',{{'type','parfor'}},'maxDist',0.011);

% figure; 
edgesEvalnoPlot(resDir,'PiDiNet');

rmdir(mat_dir, 's');
rmdir(nms_dir, 's');
toc;

