## Edge detection algorithm evaluation protocol

